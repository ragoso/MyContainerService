# MyContainerService
This is an simple abstraction of Docker (For now) Services API to easily and safely manage services from anywhere.

:warning: Be very careful with production use. **Credentials not implemented yet**.

# ToDo
- [ ] Tests, tests, tests and more tests.
- [x] GRPC Endpoint.
- [x] CLI that recives MyService json to pass on Endpoint.
- [ ] Load docker-compose.yaml.
- [ ] GRPC Authentication.
- [ ] Integrate with Kubernetes.
- [ ] UI prefered in VueJS.
- [ ] Increment this ToDo.
